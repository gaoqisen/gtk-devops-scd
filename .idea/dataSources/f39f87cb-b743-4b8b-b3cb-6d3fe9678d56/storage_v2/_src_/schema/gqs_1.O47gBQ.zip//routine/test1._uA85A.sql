create
    definer = root@`%` procedure test1(IN args int)
begin
    declare a int;
    set a = args +1;
    if a = 2 then
        INSERT INTO gqs_1.admin_user_1 (id, role) VALUES (6, 8);
    end if;
    if args = 0 then
        update gqs_1.admin_user_1 set role  = 6 where id = 8;
        else
        update gqs_1.admin_user_1 set role  = 5 where id = 8;
    end if;
end;

