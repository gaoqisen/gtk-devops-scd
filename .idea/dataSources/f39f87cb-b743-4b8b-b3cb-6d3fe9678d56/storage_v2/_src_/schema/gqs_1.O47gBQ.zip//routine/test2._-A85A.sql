create
    definer = root@`%` procedure test2(IN args int)
begin
    declare a int;
    set a = args +1;
    case a
        when 0 then
            INSERT INTO gqs_1.admin_user_1 (id, role) VALUES (6, 8);
        when 1 then
            update gqs_1.admin_user_1 set role  = 6 where id = 8;
        else
            update gqs_1.admin_user_1 set role  = 5 where id = 8;
    end case;
end;

