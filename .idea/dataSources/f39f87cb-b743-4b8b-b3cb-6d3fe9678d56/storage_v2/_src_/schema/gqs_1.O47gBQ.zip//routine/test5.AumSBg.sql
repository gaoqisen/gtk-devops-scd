create
    definer = root@`%` procedure test5()
begin
    declare a int;
    set a =0;
    l:loop
        INSERT INTO gqs_1.admin_user_1 (id, role) VALUES (a, 8);
        set a=a+1;
        if a >=5 then
            leave l;
        end if;
    end loop;
end;

