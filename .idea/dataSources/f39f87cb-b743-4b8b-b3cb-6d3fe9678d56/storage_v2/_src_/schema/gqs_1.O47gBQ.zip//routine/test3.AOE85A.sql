create
    definer = root@`%` procedure test3(IN args int)
begin
    declare a int;
    set a = args +1;
    while a <6 do
        INSERT INTO gqs_1.admin_user_1 (id, role) VALUES (a, 8);
        set a=a+1;
    end while;
end;

