create
    definer = root@`%` procedure test4()
begin
    declare a int;
    set a =0;
    repeat
        INSERT INTO gqs_1.admin_user_1 (id, role) VALUES (a, 8);
        set a=a+1;
        until a >= 5
        end repeat;
end;

