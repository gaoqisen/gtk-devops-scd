create
    definer = root@`%` procedure delete_matches(IN a_id int)
BEGIN
DELETE FROM admin_user_0
WHERE id = a_id;
END;

